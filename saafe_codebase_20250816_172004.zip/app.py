"""
Saafe Fire Detection MVP - Main Application Entry Point
Run with: streamlit run app.py
"""

from saafe_mvp.ui.dashboard import main

if __name__ == "__main__":
    main()